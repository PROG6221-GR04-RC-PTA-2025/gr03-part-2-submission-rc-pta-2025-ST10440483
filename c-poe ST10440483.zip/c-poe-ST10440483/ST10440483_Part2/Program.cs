﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading;
using System.IO;
using System.Media;

namespace ST10440483_Part2
{
    internal class Program
    {
        // Delegate for chatbot response handler
        delegate void ChatbotResponse(SpeechSynthesizer synth, string userInput);

        // Memory storage
        static string userName = "";
        static string userInterest = "";

        // Random generator
        static Random rand = new Random();

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            SpeechSynthesizer synthesizer = new SpeechSynthesizer();
            Console.Title = "TSHEGOFATSECURITY - Cyber Security Chatbot";

            DisplayGamingLogo();
            PlayVoiceGreeting();

            Speak(synthesizer, "\nHope you're doing good, what is your name? tell us your name only.");
            userName = Console.ReadLine();


            while (true)
            {
                Speak(synthesizer, $"Welcome,{userName} \n-You can ask about cybersecurity in password, phishing, privacy or scam.\n-Also you can tell if you feel curious, fraustrated or worried. \n-Tell us more about your interests by saying 'interested in' then say your interests. \n-Type 'exit' to quit or 'recall' to remember your interests");
                string userInput = Console.ReadLine().ToLower();

                if (userInput.Contains("exit"))
                {
                    Speak(synthesizer, $"Goodbye {userName}! Stay safe online.");
                    Console.ReadLine().ToLower();
                    break;
                }

                ProcessUserInput(synthesizer, userInput);
            }
        }

        static void ProcessUserInput(SpeechSynthesizer synth, string input)
        {
            // Keywords and handlers
            Dictionary<string, ChatbotResponse> keywordHandlers = new Dictionary<string, ChatbotResponse>()
            {
                { "password", PasswordTip },
                { "phishing", PhishingTips },
                { "privacy", PrivacyTip },
                { "scam", ScamAdvice }
            };

            // Sentiment detection
            if (input.Contains("worried") || input.Contains("scared"))
            {
                Speak(synth, "It's okay to feel that way. Cyber threats are real, but I'm here to help.");
            }

            else if (input.Contains("curious") || input.Contains("interested"))
            {
                Speak(synth, "Curiosity is a great start to cybersecurity awareness. Ask away!");
            }
            else if (input.Contains("frustrated") || input.Contains("angry"))
            {
                Speak(synth, "I understand. Technology can be frustrating, but you're doing great!");
            }

            // Save interest
            if (input.Contains("interested in"))
            {
                int index = input.IndexOf("interested in") + 13;
                userInterest = input.Substring(index).Trim();
                Speak(synth, $"Great! I'll remember that you're interested in {userInterest}.");
                return;
            }

            // Keyword recognition
            foreach (var keyword in keywordHandlers.Keys)
            {
                if (input.Contains(keyword))
                {
                    keywordHandlers[keyword](synth, input);
                    return;
                }
            }

            // Recall memory
            if (input.Contains("what do you remember") || input.Contains("recall"))
            {
                if (!string.IsNullOrEmpty(userInterest))
                {
                    Speak(synth, $"You mentioned you're interested in {userInterest}. That's a key area in cybersecurity.");
                }
                else
                {
                    Speak(synth, "I remember your name is " + userName + ", but you haven't told me your cybersecurity interest yet.");
                }
                return;
            }

            // Default case
            Speak(synth, "I'm not sure I understand. Can you try rephrasing?");
        }

        static void PasswordTip(SpeechSynthesizer synth, string input)
        {
            Speak(synth, "Make sure to use strong, unique passwords for each account. Avoid using personal information.");
        }

        static void PrivacyTip(SpeechSynthesizer synth, string input)
        {
            Speak(synth, "Ensure your privacy settings are up to date on all platforms. Avoid oversharing online.");
        }

        static void ScamAdvice(SpeechSynthesizer synth, string input)
        {
            Speak(synth, "Never share your personal details with unverified sources. Always verify before you trust.");
        }

        static void PhishingTips(SpeechSynthesizer synth, string input)
        {
            string[] tips = {
                "Be cautious of emails asking for personal information.",
                "Scammers often impersonate trusted organizations. Always verify the sender.",
                "Hover over links before clicking. Look out for suspicious URLs.",
                "Report suspicious emails to your IT department or email provider."
            };
            Speak(synth, tips[rand.Next(tips.Length)]);
        }

        static void Speak(SpeechSynthesizer synthesizer, string message)
        {
            synthesizer.SpeakAsync(message);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nCyberBot: " + message);
            Console.ResetColor();
            Thread.Sleep(400);
        }

        static void DisplayGamingLogo()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            string[] logo = {
                "████████╗███╗   ███╗ █████╗ ███╗   ██╗███████╗ ██████╗██╗   ██╗|",
                "╚══██╔══╝████╗ ████║██╔══██╗████╗  ██║██╔════╝██╔════╝╚██╗ ██╔╝|",
                "   ██║   ██╔████╔██║███████║██╔██╗ ██║█████╗  ██║  ███╗╚████╔╝ |",
                "   ██║   ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══╝  ██║   ██║ ╚██╔╝  |",
                "   ██║   ██║ ╚═╝ ██║██║  ██║██║ ╚████║███████╗╚██████╔╝  ██║   |",
                "   ╚═╝   ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝ ╚═════╝   ╚═╝   |",
                "____!!! -THE FUTURE OF CYBERSECURITY- !!!____|"
            };
            foreach (string line in logo)
            {
                Console.WriteLine(line);
                Thread.Sleep(100);
            }
        }

        static void PlayVoiceGreeting()
        {
            try
            {
                string audioFile = Path.Combine("poevoice.wav");
                if (File.Exists(audioFile))
                {
                    SoundPlayer play = new SoundPlayer(audioFile);
                    play.Play();
                    string greet = "Hello! Welcome to the Cybersecurity Awareness Bot. I am here to help you stay safe online.";
                    foreach (char c in greet)
                    {
                        Console.Write($"{c}");
                        Thread.Sleep(100);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing greeting: " + ex.Message);
            }
        }
    }
}
