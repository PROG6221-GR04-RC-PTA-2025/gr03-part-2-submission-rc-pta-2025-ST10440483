﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Speech.Synthesis;
using System.Media;
using System.IO;

namespace ST10440483_Part1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            SpeechSynthesizer synthesizer = new SpeechSynthesizer();
            Console.Title = "TSHEGOFATSECURITY - Cyber Security Chatbot";

            // Display cyber security Logo
            DisplayGamingLogo();

            // Play voice greeting
            PlayVoiceGreeting();
            Console.WriteLine("");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Green;
            Speak(synthesizer, "\nHope you doing good, What is your name? ");
            Console.ForegroundColor = ConsoleColor.White;
            string userName = Console.ReadLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Speak(synthesizer, $"Welcome, {userName}! How can I assist you today?");
            Console.ForegroundColor = ConsoleColor.White;

            while (true)
            {
                //Starting to ask questions of topics 
                Console.ForegroundColor = ConsoleColor.Green;
               Speak(synthesizer, "\nPlease select a cybersecurity topic: ");
                Console.WriteLine("a) Safety of Passwords");
                Console.WriteLine("b) Awareness of Phishing");
                Console.WriteLine("c) Safe Internet Surfing");
                Console.WriteLine("d) Exit");

                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Your choice: ");

                string userChoice = Console.ReadLine().ToLower();
                Console.ForegroundColor = ConsoleColor.Green;

                if (userChoice == "d")
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Speak(synthesizer, "Goodbye! Stay safe online.");
                    synthesizer.Speak("Goodbye! Stay safe online.");
                    break;
                }


                switch (userChoice)
                {
                    case "a":
                        Speak(synthesizer, "For increased security, create strong, one-of-a-kind passwords and turn on two-factor authentication, Make complicated, lengthy passwords.\r\n-Create distinct passwords for each account.\r\n\r\n-Make use of a trustworthy password manager.\r\n-Turn on two-factor verification (2FA).\r\n-Frequently change your passwords.\r\nSign up for alerts about data breaches.\r\n-Don't click on dubious links.\r\n-Never divulge your passwords to third parties.");
                        break;
                    case "b":
                        Speak(synthesizer, "Understanding the different types of phishing assaults, how a phishing email appears, how to react to emails that ask for personal information, and how they could impact the company and its employees is known as phishing awareness. Watch out for unexpected messages and emails. Before clicking on links, make sure they are correct.");
                        break;
                    case "c":
                        Speak(synthesizer, "Use HTTPS-secured websites at all times, and make sure your browser is up to date.Make use of a secure browser.\r\n:Do not click on search adverts.\r\n:Allow Notifications' pop-ups should be avoided.\r\n\r\n:Don't save private information.\r\n:Before downloading, check links.\r\n:Links should be expanded before being viewed.\r\n:Avert websites that bombard you with advertisements.\r\n:Make use of private browsing.\r\n:Regain control of your devices by doing a thorough cleaning.\r\n:Make your home network more efficient.\r\n:Update your gadgets.\r\n:Perform malware checks.\r\n:Improve the performance and security of your online browser.\r\n:For safe, encrypted connections and ad blocking, use a virtual private network (VPN).");
                        break;
                    default:
                        Speak(synthesizer, "Invalid choice. Please select a, b, c, or x to exit.");
                        continue;
                }
            }
        }

        static void DisplayGamingLogo()
        {
            //Creating logo
            Console.ForegroundColor = ConsoleColor.Yellow;
            string[] logo = {
            "████████╗███╗   ███╗ █████╗ ███╗   ██╗███████╗ ██████╗██╗   ██╗|",
            "╚══██╔══╝████╗ ████║██╔══██╗████╗  ██║██╔════╝██╔════╝╚██╗ ██╔╝|",
            "   ██║   ██╔████╔██║███████║██╔██╗ ██║█████╗  ██║  ███╗╚████╔╝ |",
            "   ██║   ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══╝  ██║   ██║ ╚██╔╝  |",
            "   ██║   ██║ ╚═╝ ██║██║  ██║██║ ╚████║███████╗╚██████╔╝  ██║   |",
            "   ╚═╝   ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝ ╚═════╝   ╚═╝   |",
            "_____________!!! -THE FUTURE OF CYBERSECURITY- !!!_____________|"
        };
            foreach (string line in logo)
            {
                Console.WriteLine(line);
                Thread.Sleep(100); // Slow reveal effect
            }

        }

        static void Speak(SpeechSynthesizer synthesizer, string message)
        {
            synthesizer.SpeakAsync(message);
            Console.WriteLine("cyberBot:" + message);
          
            Thread.Sleep(600);
        }
        //creating a greeting voice
        static void PlayVoiceGreeting()
        {
            
            try
            {
                string audioFile = Path.Combine(@"poevoice.wav");
                if (File.Exists(audioFile))
                {

                    SoundPlayer play = new SoundPlayer(audioFile);
                    play.Play();
                    Console.ForegroundColor = ConsoleColor.Green;
                    string greet = "Hello! Welcome to the Cybersecurity Awareness Bot. I am here to help you stay safe online.";
                    foreach (char c in greet)
                    {
                        Console.Write($"{c}");
                        Thread.Sleep(100);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while playing the voice greeting: " + ex.Message);
            }
        }
    }
}
